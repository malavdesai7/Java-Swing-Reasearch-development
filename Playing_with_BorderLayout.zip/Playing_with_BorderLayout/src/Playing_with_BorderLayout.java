import java.awt.*;

import javax.swing.*;

public class Playing_with_BorderLayout {

    public static void main(String[] args) {

        //Creating new colors "blueLight", "orangeBloody"
        Color blueLight = new Color(72, 128, 185);
        Color orangeBloody = new Color(253, 151, 79);

        //Create Frame
        JFrame frame = new JFrame();
        frame.setTitle("Lab 1, Question 2");
        frame.setSize(700, 500);
        frame.setAlwaysOnTop(true);

        //Main Panel
        JPanel mainPanel = new JPanel();
        mainPanel.setBackground(Color.WHITE);
        mainPanel.setLayout(new BorderLayout());

        //Create Panel1
        JPanel pan1 = new JPanel();
        pan1.setBackground(Color.WHITE);
        pan1.setPreferredSize(new Dimension(700, 85));
        mainPanel.add(pan1, BorderLayout.NORTH);

        //Create Buttons BTN1, JUSTIN
        JButton btn1 = new JButton("BTN1");
        JButton justin = new JButton("JUSTIN");

        //Change Font and size of BTN1, JUSTIN text
        btn1.setFont(new Font("Arial",Font.PLAIN, 18));
        justin.setFont(new Font("Arial",Font.PLAIN, 18));

        //Change color of BTN1, JUSTIN text
        btn1.setForeground(Color.white);
        justin.setForeground(Color.white);

        //Set color for BTN1, JUSTIN Buttons
        btn1.setBackground(blueLight);
        justin.setBackground(blueLight);

        //Set Dimensions for BTN1, JUSTIN
        btn1.setPreferredSize(new Dimension(330, 80));
        justin.setPreferredSize(new Dimension(330, 80));

        //Create Buttons BTN1, JUSTIN Borders
        btn1.setBorder(BorderFactory.createMatteBorder(5, 0, 0, 100, Color.white));
        justin.setBorder(BorderFactory.createMatteBorder(5, 100, 0, 0, Color.white));

        //Add Buttons to Panel1
        pan1.add(btn1);
        pan1.add(justin);

        //Create Panel2
        JPanel pan2 = new JPanel();
        pan2.setBackground(Color.WHITE);
        pan2.setPreferredSize(new Dimension(700, 85));
        mainPanel.add(pan2, BorderLayout.SOUTH);

        //Create Buttons John, GEORGE
        JButton john = new JButton("John");
        JButton george = new JButton("GEORGE");

        //Change Font and size of John, GEORGE text
        john.setFont(new Font("Arial",Font.PLAIN, 18));
        george.setFont(new Font("Arial",Font.PLAIN, 18));

        //Change color of John, GEORGE text
        john.setForeground(Color.white);
        george.setForeground(Color.white);

        //Set color for John, GEORGE
        john.setBackground(blueLight);
        george.setBackground(blueLight);

        //Set Dimensions for John, GEORGE
        john.setPreferredSize(new Dimension(330, 80));
        george.setPreferredSize(new Dimension(330, 80));

        //Create Buttons John, GEORGE Borders
        john.setBorder(BorderFactory.createMatteBorder(0, 0, 5, 100, Color.white));
        george.setBorder(BorderFactory.createMatteBorder(0, 100, 5, 0, Color.white));

        //Add Buttons to Panel2
        pan2.add(john);
        pan2.add(george);

        //Create Panel3a
        JPanel pan3a = new JPanel();
        pan3a.setBackground(Color.white);
        pan3a.setPreferredSize(new Dimension(155, 300));
        mainPanel.add(pan3a, BorderLayout.WEST);

        //Create Panel3b
        JPanel pan3b = new JPanel();
        pan3b.setBackground(blueLight);
        pan3b.setPreferredSize(new Dimension(145, 300));
        pan3a.add(pan3b, BorderLayout.WEST);

        //Set Dimensions for Panel3b
        pan3b.setBorder(BorderFactory.createMatteBorder(0, 6, 0, 2, Color.white));

        //Create Buttons BTN2, BTN3, BTN4
        JButton btn2 = new JButton("BTN2");
        JButton btn3 = new JButton("BTN3");
        JButton btn4 = new JButton("BTN4");

        //Change Font and size of BTN2, BTN3, BTN4 text
        btn2.setFont(new Font("Arial",Font.PLAIN, 18));
        btn3.setFont(new Font("Arial",Font.PLAIN, 18));
        btn4.setFont(new Font("Arial",Font.PLAIN, 18));

        //Change color of BTN1, BTN2, BTN3 text
        btn2.setForeground(Color.white);
        btn3.setForeground(Color.white);
        btn4.setForeground(Color.white);

        //Set color for BTN1, JUSTIN
        btn2.setBackground(orangeBloody);
        btn3.setBackground(orangeBloody);
        btn4.setBackground(orangeBloody);

        //Set Dimensions for BTN2, BTN3, BTN4
        btn2.setPreferredSize(new Dimension(115, 90));
        btn3.setPreferredSize(new Dimension(115, 90));
        btn4.setPreferredSize(new Dimension(115, 90));

        //Create Buttons BTN2, BTN3, BTN4 Borders
        btn2.setBorder(BorderFactory.createMatteBorder(5, 0, 5, 0, blueLight));
        btn3.setBorder(BorderFactory.createMatteBorder(5, 0, 5, 0, blueLight));
        btn4.setBorder(BorderFactory.createMatteBorder(5, 0, 5, 0, blueLight));

        //Add Buttons to Panel3b
        pan3b.add(btn2);
        pan3b.add(btn3);
        pan3b.add(btn4);

        //Create Panel4
        JPanel pan4 = new JPanel();
        pan4.setBackground(Color.white);
        pan4.setPreferredSize(new Dimension(105, 300));
        mainPanel.add(pan4, BorderLayout.EAST);

        //Create Button BTN5 and set to print it vertically
        JButton btn5 = new JButton("<HTML>B<br>T<br>N<br>5</HTML>");

        //Change Font and size of BTN5 text
        btn5.setFont(new Font("Arial",Font.PLAIN, 18));

        //Change color of BTN5, text
        btn5.setForeground(Color.white);

        //Set color for BTN5
        btn5.setBackground(blueLight);

        //Set Dimensions for BTN5
        btn5.setPreferredSize(new Dimension(90, 290));

        //Create Button BTN5 Borders
        btn5.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 5, Color.white));

        //Add Button to Panel4
        pan4.add(btn5);

        //Create Panel5
        JPanel pan5 = new JPanel();
        pan5.setBackground(Color.white);
        mainPanel.add(pan5, BorderLayout.CENTER);

        //Create Buttons "BIG ASS BUTTON", PAUL
        JButton bas = new JButton("BIG ASS BUTTON");
        JButton paul = new JButton("PAUL");

        //Set color for "BIG ASS BUTTON", PAUL
        bas.setBackground(blueLight);
        paul.setBackground(blueLight);

        //Change Font and size of "BIG ASS BUTTON", PAUL text
        bas.setFont(new Font("Arial",Font.PLAIN, 42));
        paul.setFont(new Font("Arial",Font.PLAIN, 18));

        //Change color of "BIG ASS BUTTON", PAUL text
        bas.setForeground(Color.white);
        paul.setForeground(Color.white);

        //Set Dimensions for "BIG ASS BUTTON", PAUL
        bas.setPreferredSize(new Dimension(426, 235));
        paul.setPreferredSize(new Dimension(426, 49));

        //Create Buttons "BIG ASS BUTTON", PAUL Borders
        bas.setBorder(BorderFactory.createMatteBorder(0, 0, 5, 0, Color.white));
        paul.setBorder(BorderFactory.createMatteBorder(0, 290, 0, 0, Color.white));

        //Add Button to Panel5
        pan5.add(bas);
        pan5.add(paul);

        //Add mainPanel to Frame
        frame.setContentPane(mainPanel);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.setVisible(true);

    }

}
